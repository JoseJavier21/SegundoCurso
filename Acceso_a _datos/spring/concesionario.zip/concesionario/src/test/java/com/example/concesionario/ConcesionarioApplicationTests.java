package com.example.concesionario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcesionarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
