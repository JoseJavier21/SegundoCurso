//
//  SliderUnoaDiez.swift
//  EjerCalDesing
//
//  Created by dam2 on 20/11/23.
//

import UIKit

class SliderUnoaDiez: UISlider {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    
}
