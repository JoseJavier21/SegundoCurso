//
//  ViewController.swift
//  Examen2_Rojo_Jose_Javier
//
//  Created by dam2 on 13/12/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

