//
//  Respuesta.swift
//  RickAndMorty
//
//  Created by dam2 on 19/12/23.
//

import Foundation

struct Respuesta: Decodable{
    var results: [PersonajeModel]    
}
