//
//  MiCeldaCollectionViewCell.swift
//  RickAndMorty
//
//  Created by dam2 on 18/12/23.
//

import UIKit

class MiCeldaCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var especie: UILabel!
    
    
}
